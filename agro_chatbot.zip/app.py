
import gradio as gr
import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# تحميل البيانات
df_kaggle = pd.read_csv("AgroQA_Dataset.csv")
df_kaggle_clean = df_kaggle[['Question', 'Answer']].copy()
df_kaggle_clean.columns = ['question', 'answer']

# تحميل النموذج و ترميز الأسئلة
model = SentenceTransformer('all-MiniLM-L6-v2')
question_embeddings = model.encode(df_kaggle_clean['question'].tolist(), show_progress_bar=True)

def chatbot_response(user_question):
    user_embedding = model.encode([user_question])
    similarities = cosine_similarity(user_embedding, question_embeddings)[0]
    top_idx = similarities.argmax()
    
    answer = df_kaggle_clean.iloc[top_idx]['answer']
    return answer

# واجهة Gradio
iface = gr.Interface(fn=chatbot_response, 
                     inputs="text", 
                     outputs="text", 
                     title="🌿 Smart Agro Chatbot",
                     description="اسألني عن الزراعة، وسأجيبك بمعلومة دقيقة 🌱")
iface.launch()
